#ifndef _FSVUB_CAN_DFS_H_
#define _FSVUB_CAN_DFS_H_


#define MAX_CAN_ID 0x7FF

#define CAN_MESSAGE_TOO_LONG    100

// Message ID defines
#define FSVUB_ERR       0x000       // ERROR CODE

#define FSVUB_TPS1      0x003       // Throttle Position Sensor 1
#define FSVUB_TPS2      0x004       // Throttle Position Sensor 2
#define FSVUB_BPS1      0x005       // Brake pressure sensor 1
#define FSVUB_BPS2      0x006       // Brake pressure sensor 2

#define FSVUB_SAS       0x007       // Steering Angle Sensor
#define FSVUB_SPEED1    0x008       // Measured Speed 1
#define FSVUB_SPEED2    0x009       // Measured Speed 2
#define FSVUB_SPEED3    0x010       // Measured Speed 3
#define FSVUB_SPEED4    0x011       // Measured Speed 4

#define FSVUB_HV_STATE      0x020   // Current state of the AIRs and HV line
#define FSVUB_HV_ON         0x021   // Signal to turn HV on
#define FSVUB_RTD_ON        0x022   // Signal to set car in ready to drive mode
#define FSVUB_DRIVE_MODE    0X023   // Switch between current and speed drive mode in the invertor
#define FSVUB_RTDS          0x024   // Ready to drive sound

#define FSVUB_LMSR      0x001       // Left Motor Speed request
#define FSVUB_LMPD      0x200       // Left Motor power draw
#define FSVUB_LMT1      0x201       // Left Motor Temp 1
#define FSVUB_LMT2      0x202       // Left Motor Temp 2
#define FSVUB_LMT3      0x203       // Left Motor Temp 3
#define FSVUB_LMT4      0x204       // Left Motor Temp 4

#define FSVUB_RMSR      0x002       // Right Motor Speed request
#define FSVUB_RMPD      0x210       // Left Motor power draw
#define FSVUB_RMT1      0x211       // Right Motor Temp 1
#define FSVUB_RMT2      0x212       // Right Motor Temp 2
#define FSVUB_RMT3      0x213       // Right Motor Temp 3
#define FSVUB_RMT4      0x214       // Right Motor Temp 4

#define FSVUB_LFWS      0x220       // Left front wheel speed
#define FSVUB_LFACC     0x221       // Left front accelerometer sensor
#define FSVUB_LFSA      0x223       // Left front suspension angle sensor
#define FSVUB_LFDT      0x224       // Left Front Disc Temperature

#define FSVUB_LRWS      0x230       // Left rear wheel speed
#define FSVUB_LRACC     0x231       // Left rear accelerometer sensor
#define FSVUB_LRSA      0x233       // Left rear suspension angle sensor
#define FSVUB_LRDT      0x234       // Left Rear Disc Temperature

#define FSVUB_RFWS      0x240       // Right front wheel speed
#define FSVUB_RFACC     0x241       // Right front accelerometer sensor
#define FSVUB_RFSA      0x243       // Right front suspension angle sensor
#define FSVUB_RFDT      0x244       // Right Front Disc Temperature

#define FSVUB_RRWS      0x250       // Right rear wheel speed
#define FSVUB_RRACC     0x251       // Right rear accelerometer sensor
#define FSVUB_RRSA      0x253       // Right rear suspension angle sensor
#define FSVUB_RRDT      0x254       // Right Rear Disc Temperature

#define FSVUB_HST1      0x260       // Heat sink temp 1
#define FSVUB_HST2      0x261       // Heat sink temp 2
#define FSVUB_HST3      0x262       // Heat sink temp 3
#define FSVUB_HST4      0x263       // Heat sink temp 4

#define FSVUB_SOC       0x270        // State of Charge
#define FSVUB_BPO       0x271        // Battery Power Out
#define FSVUB_BTS       0x272        // Battery Temperature Sensor
#define FSVUB_BCV       0x273        // Battery cell voltage

#define FSVUB_TIME      0x280        // Local time
#define FSVUB_TIME_SET  0x281        // Time has been set confirmation

#define FSVUB_MSG       0x2FF        // Message to display


#define ACC_X   1   // Accelerometer x axis id
#define ACC_Y   2   // Accelerometer y axis id
#define ACC_Z   3   // Accelerometer z axis id

#define GYRO_X  4   // Gyroscope x axis id
#define GYRO_Y  5   // Gyroscope y axis id
#define GYRO_Z  6   // Gyroscope z axis id


#define BATTERY_CELLV_P0_0  0   // Cell Voltages of pack 1, cells 1-4
#define BATTERY_CELLV_P0_1  1   // Cell Voltages of pack 1, cells 5-8
#define BATTERY_CELLV_P0_2  2   // Cell Voltages of pack 1, cells 9-12
#define BATTERY_CELLV_P0_3  3   // Cell Voltages of pack 1, cell 13 last 2 positions filled with -1

#define BATTERY_CELLV_P1_0  10   // Cell Voltages of pack 2, cells 1-4
#define BATTERY_CELLV_P1_1  11   // Cell Voltages of pack 2, cells 5-8
#define BATTERY_CELLV_P1_2  12   // Cell Voltages of pack 2, cells 9-12
#define BATTERY_CELLV_P1_3  13   // Cell Voltages of pack 2, cell 13 last 2 positions filled with -1

#define BATTERY_CELLV_P2_0  20   // Cell Voltages of pack 3, cells 1-4
#define BATTERY_CELLV_P2_1  21   // Cell Voltages of pack 3, cells 5-8
#define BATTERY_CELLV_P2_2  22   // Cell Voltages of pack 3, cells 9-12
#define BATTERY_CELLV_P2_3  23   // Cell Voltages of pack 3, cell 13 last 2 positions filled with -1

#define BATTERY_CELLV_P3_0  30   // Cell Voltages of pack 4, cells 1-4
#define BATTERY_CELLV_P3_1  31   // Cell Voltages of pack 4, cells 5-8
#define BATTERY_CELLV_P3_2  32   // Cell Voltages of pack 4, cells 9-12
#define BATTERY_CELLV_P3_3  33   // Cell Voltages of pack 4, cell 13 last 2 positions filled with -14

#define BATTERY_CELLV_P4_0  40   // Cell Voltages of pack 5, cells 1-4
#define BATTERY_CELLV_P4_1  41   // Cell Voltages of pack 5, cells 5-8
#define BATTERY_CELLV_P4_2  42   // Cell Voltages of pack 5, cells 9-12
#define BATTERY_CELLV_P4_3  43   // Cell Voltages of pack 5, cell 13 last 2 positions filled with -5

#define BATTERY_CELLV_P5_0  50   // Cell Voltages of pack 6, cells 1-4
#define BATTERY_CELLV_P5_1  51   // Cell Voltages of pack 6, cells 5-8
#define BATTERY_CELLV_P5_2  52   // Cell Voltages of pack 6, cells 9-12
#define BATTERY_CELLV_P5_3  53   // Cell Voltages of pack 6, cell 13 last 2 positions filled with -1

#define BATTERY_CELLV_P6_0  60   // Cell Voltages of pack 7, cells 1-4
#define BATTERY_CELLV_P6_1  61   // Cell Voltages of pack 7, cells 5-8
#define BATTERY_CELLV_P6_2  62   // Cell Voltages of pack 7, cells 9-12
#define BATTERY_CELLV_P6_3  63   // Cell Voltages of pack 7, cell 13 last 2 positions filled with -1

#define BATTERY_CELLV_P7_0  70   // Cell Voltages of pack 8, cells 1-4
#define BATTERY_CELLV_P7_1  71   // Cell Voltages of pack 8, cells 5-8
#define BATTERY_CELLV_P7_2  72   // Cell Voltages of pack 8, cells 9-12
#define BATTERY_CELLV_P7_3  73   // Cell Voltages of pack 8, cell 13 last 2 positions filled with -1

#define BATTERY_TEMP_P0_0  100   // Cell Temperatures of pack 1, Temperatures 1-7
#define BATTERY_TEMP_P0_1  101   // Cell Temperatures of pack 1, Temperatures 8-14
#define BATTERY_TEMP_P0_2  102   // Cell Temperatures of pack 1, Temperatures 14-21
#define BATTERY_TEMP_P0_3  103   // Cell Temperatures of pack 1, Temperatures 22-28
#define BATTERY_TEMP_P0_4  104   // Cell Temperatures of pack 1, Temperatures 29-35
#define BATTERY_TEMP_P0_5  105   // Cell Temperatures of pack 1, Temperatures 36-42
#define BATTERY_TEMP_P0_6  106   // Cell Temperatures of pack 1, Temperatures 43-49
#define BATTERY_TEMP_P0_7  107   // Cell Temperatures of pack 1, Temperatures 50-57 last 5 positions filled with -1

#define BATTERY_TEMP_P1_0  110   // Cell Temperatures of pack 2, Temperatures 1-7
#define BATTERY_TEMP_P1_1  111   // Cell Temperatures of pack 2, Temperatures 8-14
#define BATTERY_TEMP_P1_2  112   // Cell Temperatures of pack 2, Temperatures 14-21
#define BATTERY_TEMP_P1_3  113   // Cell Temperatures of pack 2, Temperatures 22-28
#define BATTERY_TEMP_P1_4  114   // Cell Temperatures of pack 2, Temperatures 29-35
#define BATTERY_TEMP_P1_5  115   // Cell Temperatures of pack 2, Temperatures 36-42
#define BATTERY_TEMP_P1_6  116   // Cell Temperatures of pack 2, Temperatures 43-49
#define BATTERY_TEMP_P1_7  117   // Cell Temperatures of pack 2, Temperatures 50-57 last 5 positions filled with -1

#define BATTERY_TEMP_P2_0  120   // Cell Temperatures of pack 3, Temperatures 1-7
#define BATTERY_TEMP_P2_1  121   // Cell Temperatures of pack 3, Temperatures 8-14
#define BATTERY_TEMP_P2_2  122   // Cell Temperatures of pack 3, Temperatures 14-21
#define BATTERY_TEMP_P2_3  123   // Cell Temperatures of pack 3, Temperatures 22-28
#define BATTERY_TEMP_P2_4  124   // Cell Temperatures of pack 3, Temperatures 29-35
#define BATTERY_TEMP_P2_5  125   // Cell Temperatures of pack 3, Temperatures 36-42
#define BATTERY_TEMP_P2_6  126   // Cell Temperatures of pack 3, Temperatures 43-49
#define BATTERY_TEMP_P2_7  127   // Cell Temperatures of pack 3, Temperatures 50-57 last 5 positions filled with -1

#define BATTERY_TEMP_P3_0  130   // Cell Temperatures of pack 4, Temperatures 1-7
#define BATTERY_TEMP_P3_1  131   // Cell Temperatures of pack 4, Temperatures 8-14
#define BATTERY_TEMP_P3_2  132   // Cell Temperatures of pack 4, Temperatures 14-21
#define BATTERY_TEMP_P3_3  133   // Cell Temperatures of pack 4, Temperatures 22-28
#define BATTERY_TEMP_P3_4  134   // Cell Temperatures of pack 4, Temperatures 29-35
#define BATTERY_TEMP_P3_5  135   // Cell Temperatures of pack 4, Temperatures 36-42
#define BATTERY_TEMP_P3_6  136   // Cell Temperatures of pack 4, Temperatures 43-49
#define BATTERY_TEMP_P3_7  137   // Cell Temperatures of pack 4, Temperatures 50-57 last 5 positions filled with -1

#define BATTERY_TEMP_P4_0  140   // Cell Temperatures of pack 5, Temperatures 1-7
#define BATTERY_TEMP_P4_1  141   // Cell Temperatures of pack 5, Temperatures 8-14
#define BATTERY_TEMP_P4_2  142   // Cell Temperatures of pack 5, Temperatures 14-21
#define BATTERY_TEMP_P4_3  143   // Cell Temperatures of pack 5, Temperatures 22-28
#define BATTERY_TEMP_P4_4  144   // Cell Temperatures of pack 5, Temperatures 29-35
#define BATTERY_TEMP_P4_5  145   // Cell Temperatures of pack 5, Temperatures 36-42
#define BATTERY_TEMP_P4_6  146   // Cell Temperatures of pack 5, Temperatures 43-49
#define BATTERY_TEMP_P4_7  147   // Cell Temperatures of pack 5, Temperatures 50-57 last 5 positions filled with -1

#define BATTERY_TEMP_P5_0  150   // Cell Temperatures of pack 6, Temperatures 1-7
#define BATTERY_TEMP_P5_1  151   // Cell Temperatures of pack 6, Temperatures 8-14
#define BATTERY_TEMP_P5_2  152   // Cell Temperatures of pack 6, Temperatures 14-21
#define BATTERY_TEMP_P5_3  153   // Cell Temperatures of pack 6, Temperatures 22-28
#define BATTERY_TEMP_P5_4  154   // Cell Temperatures of pack 6, Temperatures 29-35
#define BATTERY_TEMP_P5_5  155   // Cell Temperatures of pack 6, Temperatures 36-42
#define BATTERY_TEMP_P5_6  156   // Cell Temperatures of pack 6, Temperatures 43-49
#define BATTERY_TEMP_P5_7  157   // Cell Temperatures of pack 6, Temperatures 50-57 last 5 positions filled with -1

#define BATTERY_TEMP_P6_0  160   // Cell Temperatures of pack 7, Temperatures 1-7
#define BATTERY_TEMP_P6_1  161   // Cell Temperatures of pack 7, Temperatures 8-14
#define BATTERY_TEMP_P6_2  162   // Cell Temperatures of pack 7, Temperatures 14-21
#define BATTERY_TEMP_P6_3  163   // Cell Temperatures of pack 7, Temperatures 22-28
#define BATTERY_TEMP_P6_4  164   // Cell Temperatures of pack 7, Temperatures 29-35
#define BATTERY_TEMP_P6_5  165   // Cell Temperatures of pack 7, Temperatures 36-42
#define BATTERY_TEMP_P6_6  166   // Cell Temperatures of pack 7, Temperatures 43-49
#define BATTERY_TEMP_P6_7  167   // Cell Temperatures of pack 7, Temperatures 50-57 last 5 positions filled with -1

#define BATTERY_TEMP_P7_0  170   // Cell Temperatures of pack 8, Temperatures 1-7
#define BATTERY_TEMP_P7_1  171   // Cell Temperatures of pack 8, Temperatures 8-14
#define BATTERY_TEMP_P7_2  172   // Cell Temperatures of pack 8, Temperatures 14-21
#define BATTERY_TEMP_P7_3  173   // Cell Temperatures of pack 8, Temperatures 22-28
#define BATTERY_TEMP_P7_4  174   // Cell Temperatures of pack 8, Temperatures 29-35
#define BATTERY_TEMP_P7_5  175   // Cell Temperatures of pack 8, Temperatures 36-42
#define BATTERY_TEMP_P7_6  176   // Cell Temperatures of pack 8, Temperatures 43-49
#define BATTERY_TEMP_P7_7  177   // Cell Temperatures of pack 8, Temperatures 50-57 last 5 positions filled with -1

#define BATTERY_SOC 200 //Battery State of Charge
#define BATTERY_VOLTAGE 201 //Battery Voltages
#define BATTERY_CURRENT 202 //Current drawn from battery



#endif  // _FSVUB_CAN_DFS_H_
