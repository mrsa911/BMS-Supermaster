#include "FSVUB_CAN_dfs.h"
#include "mcp_can.h"

#ifndef _FSVUB_CAN_H_
#define _FSVUB_CAN_H_

uint16_t floatToInt(float limitL, float limitH, float fl);
float intToFloat(float limitL, float limitH, uint16_t data);
byte floatToByte(float limitL, float limitH, float fl);
float byteToFloat(float limitL, float limitH, uint8_t data);

/*********************************************************************************************************
** Class name:              FSVUB_CAN
** Descriptions:            declaration of the FSVUB_CAN class
*********************************************************************************************************/
class FSVUB_CAN : public MCP_CAN
{
private:
    bool m_isSetupComplete = false;
    unsigned m_defaultTxID = MAX_CAN_ID;
    byte null = 0;

public:
    FSVUB_CAN(byte _cs, const unsigned long spiSpeed = 8000000L);
    void setup(byte speedset = CAN_1000KBPS, const byte clockset = MCP_16MHz);
    void begin(byte speedset = CAN_1000KBPS, const byte clockset = MCP_16MHz);
    inline byte sendMsgBuf(unsigned int id, byte len, const byte* buff) __attribute__((always_inline));
    inline byte sendMsgBuf(unsigned int id, const byte* buff) __attribute__((always_inline));
    inline byte sendMsgBuf(const byte* buff) __attribute__((always_inline));
    void setDefaultTxID(unsigned int id);

    template <class T, byte N>
    byte sendMsgData(unsigned canID, byte messageID, const T (&data)[N]);

    template <class T, byte N>
    inline byte sendMsgData(unsigned canID, const T (&data)[N]) __attribute__((always_inline));

    template <class T>
    inline byte sendMsgData(unsigned canID, byte messageID, const T data) __attribute__((always_inline));

    template <class T>
    inline byte sendMsgData(unsigned canID, const T data) __attribute__((always_inline));

    template <class T, byte N>
    void readMsgData(const byte* buff, byte& messageID, T (&data)[N]);

    template <class T, byte N>
    inline void readMsgData(const byte* buff, T (&data)[N]) __attribute__((always_inline));

    template <class T>
    inline void readMsgData(const byte* buff, byte& messageID, T& data) __attribute__((always_inline));

    template <class T>
    inline void readMsgData(const byte* buff, T& data) __attribute__((always_inline));
};

/*********************************************************************************************************
** Function name:           sendMsgBuf
** Descriptions:            send buf
*********************************************************************************************************/
inline byte FSVUB_CAN::sendMsgBuf(unsigned int id, byte len, const byte* buff)  // inline functions need to be kept in the header file
{
    return MCP_CAN::sendMsgBuf(id, 0, len, buff);
}

/*********************************************************************************************************
** Function name:           sendMsgBuf
** Descriptions:            send buf
*********************************************************************************************************/
inline byte FSVUB_CAN::sendMsgBuf(unsigned int id, const byte* buff)
{
    return MCP_CAN::sendMsgBuf(id, 0, 8, buff);
}

/*********************************************************************************************************
** Function name:           sendMsgBuf
** Descriptions:            send buf
*********************************************************************************************************/
inline byte FSVUB_CAN::sendMsgBuf(const byte* buff)
{
    return MCP_CAN::sendMsgBuf(m_defaultTxID, 0, 8, buff);
}

/*********************************************************************************************************
** Function name:           sendMsgData
** Descriptions:            convert an array of data to an array of bytes and send those over the can bus
*********************************************************************************************************/
template <class T, byte N>
byte FSVUB_CAN::sendMsgData(unsigned canID, byte messageID, const T (&data)[N])     // template functions need to be kept in the header file
{
    union {  // Convert data to an array of bytes so we can read each byte individually
        const T* data;
        const byte* bytes;
    } byteData;

    byteData.data = data;

    if (messageID == 0)
    {
        return MCP_CAN::sendMsgBuf(canID, 0, sizeof(data), byteData.bytes);
    }
    else
    {
        byte buff[1 + sizeof(data)];
        memcpy(buff, byteData.bytes, sizeof(data));
        buff[sizeof(data)] = messageID;  // Add messageID at the end of the buffer
        return MCP_CAN::sendMsgBuf(canID, 0, 1 + sizeof(data), buff, false);
    }
}

/*********************************************************************************************************
** Function name:           sendMsgData
** Descriptions:            convert an array of data to an array of bytes and send those over the can bus
*********************************************************************************************************/
template <class T, byte N>
inline byte FSVUB_CAN::sendMsgData(unsigned canID, const T (&data)[N])
{
    return sendMsgData<T, N>(canID, 0, data);
}

/*********************************************************************************************************
** Function name:           sendMsgData
** Descriptions:            convert a value to an array of bytes and send those over the can bus
*********************************************************************************************************/
template <class T>
inline byte FSVUB_CAN::sendMsgData(unsigned canID, byte messageID, const T data)
{
    return sendMsgData<T, 1>(canID, messageID, (T[]){data});
}

/*********************************************************************************************************
** Function name:           sendMsgData
** Descriptions:            convert a value to an array of bytes and send those over the can bus
*********************************************************************************************************/
template <class T>
inline byte FSVUB_CAN::sendMsgData(unsigned canID, const T data)
{
    return sendMsgData<T, 1>(canID, 0, (T[]){data});
}

/*********************************************************************************************************
** Function name:           readMsgData
** Descriptions:            convert an array of bytes to an array of data of the correct datatype
*********************************************************************************************************/
template <class T, byte N>
void FSVUB_CAN::readMsgData(const byte* buff, byte& messageID, T (&data)[N])
{
    if (&messageID != &null)
        messageID = buff[sizeof(data)];

    union {
        const T* data;
        const byte* bytes;
    } byteData;

    byteData.bytes = buff;

    memcpy(data, byteData.data, sizeof(data));
}

/*********************************************************************************************************
** Function name:           readMsgData
** Descriptions:            convert an array of bytes to an array of data of the correct datatype
*********************************************************************************************************/
template <class T, byte N>
inline void FSVUB_CAN::readMsgData(const byte* buff, T (&data)[N])
{
    readMsgData<T, N>(buff, null, data);
}

/*********************************************************************************************************
** Function name:           readMsgData
** Descriptions:            convert an array of bytes to a value of the correct datatype
*********************************************************************************************************/
template <class T>
inline void FSVUB_CAN::readMsgData(const byte* buff, byte& messageID, T& data)
{
    T temp[1];
    readMsgData<T, 1>(buff, messageID, temp);
    data = temp[0];
}

/*********************************************************************************************************
** Function name:           readMsgData
** Descriptions:            convert an array of bytes to a value of the correct datatype
*********************************************************************************************************/
template <class T>
inline void FSVUB_CAN::readMsgData(const byte* buff, T& data)
{
    T temp[1];
    readMsgData<T, 1>(buff, null, temp);
    data = temp[0];
}

#endif  // _FSVUB_CAN_H_
