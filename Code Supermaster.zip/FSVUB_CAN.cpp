#include "FSVUB_CAN.h"

/*********************************************************************************************************
** Function name:           floatToInt
** Descriptions:            map a float to a 16 bit value
*********************************************************************************************************/
uint16_t floatToInt(float limitL, float limitH, float fl)
{
    if (fl < limitL)
    {
        return 0;
    }
    if (fl > limitH)
    {
        return UINT16_MAX;
    }

    return (fl - limitL) * UINT16_MAX / (limitH - limitL) + 0.5;
}

/*********************************************************************************************************
** Function name:           intToFloat
** Descriptions:            map a 16 bit value to a float
*********************************************************************************************************/
float intToFloat(float limitL, float limitH, uint16_t data)
{
    return limitL + ((float)data / UINT16_MAX) * (limitH - limitL);
}

/*********************************************************************************************************
** Function name:           floatToByte
** Descriptions:            map a float to an 8 bit value
*********************************************************************************************************/
byte floatToByte(float limitL, float limitH, float fl)
{
    if (fl < limitL)
    {
        return 0;
    }
    if (fl > limitH)
    {
        return UINT8_MAX;
    }

    return (fl - limitL) * UINT8_MAX / (limitH - limitL) + 0.5;
}

/*********************************************************************************************************
** Function name:           byteToFloat
** Descriptions:            map an 8 bit value to a float
*********************************************************************************************************/
float byteToFloat(float limitL, float limitH, uint8_t data)
{
    return limitL + ((float)data / UINT8_MAX) * (limitH - limitL);
}

/*********************************************************************************************************
** Function name:           FSVUB_CAN
** Descriptions:            Constructor
*********************************************************************************************************/
FSVUB_CAN::FSVUB_CAN(byte _cs, const unsigned long spiSpeed) : MCP_CAN(_cs, spiSpeed)
{
    pSPI->begin();
};

/*********************************************************************************************************
** Function name:           setup
** Descriptions:            init can and set speed
*********************************************************************************************************/
void FSVUB_CAN::setup(byte speedset, const byte clockset)
{
    while (CAN_OK != MCP_CAN::begin(speedset, clockset))
    {
#ifdef __AVR_ATmega32U4__
        Serial1.println(F("CAN BUS setup failed"));
        Serial1.println(F("Retrying..."));
#else
        Serial.println(F("CAN BUS setup failed"));
        Serial.println(F("Retrying..."));
#endif
        delay(100);
    }
    m_isSetupComplete = true;
}

/*********************************************************************************************************
** Function name:           sendMsgBuf
** Descriptions:            set a default filter to remove all non important data
*********************************************************************************************************/
void FSVUB_CAN::begin(byte speedset, const byte clockset)
{
    if (!m_isSetupComplete)
    {
        setup(speedset, clockset);

        // Filter rules
        // ╔════════════╦══════════════╦════════════════╦════════╗
        // ║ Mask bit n ║ Filter bit n ║ Message id bit ║        ║
        // ╠════════════╬══════════════╬════════════════╬════════╣
        // ║      0     ║       x      ║        x       ║ Accept ║
        // ╠════════════╬══════════════╬════════════════╬════════╣
        // ║      1     ║       0      ║        0       ║ Accept ║
        // ╠════════════╬══════════════╬════════════════╬════════╣
        // ║      1     ║       0      ║        1       ║ Reject ║
        // ╠════════════╬══════════════╬════════════════╬════════╣
        // ║      1     ║       1      ║        0       ║ Reject ║
        // ╠════════════╬══════════════╬════════════════╬════════╣
        // ║      1     ║       1      ║        1       ║ Accept ║
        // ╚════════════╩══════════════╩════════════════╩════════╝

        // there are 2 mask in mcp2515, you need to set both of them
        init_Mask(0, 0, 0x200);  // For Receive register 0   (10 bit value, msb 11th bit is ignored)
        init_Mask(1, 0, 0x200);  // For Receive register 1

        // there are 6 filter in mcp2515
        init_Filt(0, 0, 0x00);  // For Receive register 0
        init_Filt(1, 0, 0x00);

        init_Filt(2, 0, 0x00);  // For Receive register 1
        init_Filt(3, 0, 0x00);
        init_Filt(4, 0, 0x00);
        init_Filt(5, 0, 0x00);

        m_isSetupComplete = true;
    }

    if (mcp2515_setCANCTRL_Mode(MODE_NORMAL) != MCP2515_OK)
#ifdef __AVR_ATmega32U4__
        Serial1.println(F("Enter normal mode failed"));
#else
        Serial.println(F("Enter normal mode failed"));
#endif

    else
#ifdef __AVR_ATmega32U4__
        Serial1.println(F("CAN BUS setup ok!"));
#else
        Serial.println(F("CAN BUS setup ok!"));
#endif
}

/*********************************************************************************************************
** Function name:           sendMsgBuf
** Descriptions:            send buf
*********************************************************************************************************/
void FSVUB_CAN::setDefaultTxID(unsigned int id)
{
    if (id > MAX_CAN_ID)
    {
#ifdef __AVR_ATmega32U4__
        Serial1.println(F("Default id is too large!"));
#else
        Serial.println(F("Default id is too large!"));
#endif

        return;
    }
    m_defaultTxID = id;
}
